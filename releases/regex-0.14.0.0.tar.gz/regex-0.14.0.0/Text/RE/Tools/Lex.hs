module Text.RE.Tools.Lex
  ( alex
  , alex'
  -- * IsRegex
  , IsRegex(..)
  -- * Text.RE
  , module Text.RE
  ) where

import           Text.RE
import           Text.RE.ZeInternals.Tools.Lex
