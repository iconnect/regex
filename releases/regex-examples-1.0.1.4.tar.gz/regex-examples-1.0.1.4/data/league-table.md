# Premier League 2015-16: Top 7

Pos|Club                 |Played |Won    |Drawn  |Lost   |GF     |GA     |GD     |Points 
---|---------------------|-------|-------|-------|-------|-------|-------|-------|-------
1  |West Ham United      |12     |5      |4      |3      |19     |18     |1      |19     
2  |Tottenham Hotspur    |12     |5      |3      |4      |20     |12     |8      |18     
3  |Leicester City       |12     |4      |6      |2      |17     |16     |1      |18     
4  |Southampton FC       |12     |5      |2      |5      |18     |16     |2      |17     
5  |Arsenal FC           |12     |4      |5      |3      |22     |21     |1      |17     
6  |Manchester United    |12     |4      |4      |4      |12     |16     |-4     |16     
7  |Manchester City      |12     |1      |4      |7      |14     |23     |-9     |7      
